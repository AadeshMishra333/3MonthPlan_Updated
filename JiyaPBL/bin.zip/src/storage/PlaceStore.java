package storage;

import model.Place;
import java.nio.file.*;
import java.io.*;
import java.util.*;

public class PlaceStore {
    private final Path file;
    private final List<Place> list = new ArrayList<>();
    private int nextId = 1;

    public PlaceStore(String filePath) {
        this.file = Paths.get(filePath);
        load();
    }

    public synchronized void load() {
        list.clear();
        if (!Files.exists(file)) return;
        try (BufferedReader br = Files.newBufferedReader(file)) {
            String line;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                Place p = Place.fromCsv(line);
                if (p != null) list.add(p);
            }
            nextId = list.stream().mapToInt(x -> x.id).max().orElse(0) + 1;
        } catch (IOException e) {
            System.out.println("Load failed: " + e.getMessage());
        }
    }

    public synchronized void save() {
        try {
            if (!Files.exists(file.getParent())) Files.createDirectories(file.getParent());
        } catch (IOException e) {
            System.out.println("Failed to create data directory: " + e.getMessage());
        }

        try (BufferedWriter bw = Files.newBufferedWriter(file)) {
            for (Place p : list) bw.write(p.toCsv() + "\n");
        } catch (IOException e) {
            System.out.println("Save failed: " + e.getMessage());
        }
    }

    public synchronized Place add(String name, String cat, String addr, double rating) {
        Place p = new Place(nextId++, name, cat, addr, rating);
        list.add(p);
        return p;
    }

    public synchronized boolean delete(int id) {
        return list.removeIf(x -> x.id == id);
    }

    public synchronized List<Place> search(String q) {
        String L = q.toLowerCase();
        List<Place> out = new ArrayList<>();
        for (Place p : list) {
            if (p.name.toLowerCase().contains(L)
             || p.category.toLowerCase().contains(L)
             || p.address.toLowerCase().contains(L)) out.add(p);
        }
        return out;
    }

    public synchronized List<Place> all() {
        return new ArrayList<>(list);
    }
}
