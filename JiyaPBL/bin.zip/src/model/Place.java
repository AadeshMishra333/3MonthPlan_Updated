package model;

public class Place {
    public int id;
    public String name;
    public String category;
    public String address;
    public double rating;

    public Place(int id, String name, String category, String address, double rating) {
        this.id = id;
        this.name = name;
        this.category = category;
        this.address = address;
        this.rating = rating;
    }

    @Override
    public String toString() {
        return id + " | " + name + " (" + category + ") - " + rating + " | " + address;
    }

    public String toCsv() {
        return id + "," + safe(name) + "," + safe(category) + "," + safe(address) + "," + rating;
    }

    private static String safe(String s) {
        return s == null ? "" : s.replace(",", " ");
    }

    public static Place fromCsv(String line) {
        String[] p = line.split(",", -1);
        try {
            int id = Integer.parseInt(p[0]);
            String name = p[1];
            String cat = p[2];
            String addr = p[3];
            double r = Double.parseDouble(p[4]);
            return new Place(id, name, cat, addr, r);
        } catch (Exception ex) {
            return null;
        }
    }
}

