package app;

import storage.PlaceStore;
import ui.Menu;

public class App {
    public static void main(String[] args) {
        PlaceStore store = new PlaceStore("data/places.csv");
        new Menu(store).start();
    }
}
